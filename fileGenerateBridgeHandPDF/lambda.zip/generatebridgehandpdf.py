#!/usr/bin/python

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

SPADE = u'\u2660'
HEART = u'\u2665'
DIAMOND = u'\u2666' 
CLUB = u'\u2663'




canvas = canvas.Canvas("test.pdf", pagesize=letter)
canvas.setLineWidth(.3)

canvas.setFillColorRGB(255, 0, 0)
canvas.drawString(30,750,HEART)

canvas.setFillColorRGB(0, 0, 0)
canvas.drawString(60,750,SPADE)

canvas.setFillColorRGB(255, 0, 0)
canvas.drawString(90,750,DIAMOND)

canvas.setFillColorRGB(0, 0, 0)
canvas.drawString(120,750,CLUB)

canvas.save()
